package CS

import (
	"bufio"
	"fmt"
	"log"
	"net"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
	"sort"
)

var k = -1
var nuevosNodos = true
var nuevasRespuestas = &sync.Mutex{}
var respuestas = &sync.Mutex{}
var IPS []string
var DatasetStrings []string
var Distancias []Knn

type Knn struct {
	Instancia []int
	Distancia float64
}

func Servidor() {
	// Ingresar IP
	ipS := "192.168.1.15"

	rutaData := "cancer.csv"
	leerData(rutaData)

	
	gin := bufio.NewReader(os.Stdin)

	for k <= 0 || k%2 == 0 {
		fmt.Print("Ingresar valor de K: ")

		newK, _ := gin.ReadString('\n')
		newK = strings.TrimSpace(newK)

		k, _ = strconv.Atoi(newK)

		if k <= 0 {
			fmt.Print("K tiene que ser positivo\n")
		}

		if k%2 == 0 {
			fmt.Print("K tiene que ser impar\n")
		}

		if k >= len(DatasetStrings) {
			fmt.Printf("K tiene que ser neor a las instancias del dataset (%d)\n", len(DatasetStrings))
		}
	}

	fmt.Printf("Tu IP es %s:8000\n", ipS)

	respuestas.Lock()

	go escucharNodos(ipS)
	go losResultados(ipS)


	fmt.Print("Esperando clientes, presionar enter para empezar\n")
	gin.ReadString('\n')
	nuevosNodos = false

	repartirData()
	transferencia()

	ImprimirRespuestas()
}

func leerData(rutaData string) {
	ubicacionAbsoluta, _ := filepath.Abs(rutaData)

	file, err := os.Open(ubicacionAbsoluta)

	if err != nil {
		log.Fatal(err)
	}

	defer file.Close()

	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := scanner.Text()
		DatasetStrings = append(DatasetStrings, line)
	}

	if err := scanner.Err(); err != nil {
		log.Fatal(err)
	}
}

func escucharNodos(hostAddr string) {
	host := fmt.Sprintf("%s:8000", hostAddr)
	ln, _ := net.Listen("tcp", host)
	defer ln.Close()

	for nuevosNodos {
		conn, _ := ln.Accept()
		go registrarNodo(conn)
	}
}

func registrarNodo(conn net.Conn) {
	defer conn.Close()

	if !nuevosNodos {
		return
	}

	r := bufio.NewReader(conn)
	remoteIp, _ := r.ReadString('\n')
	remoteIp = strings.TrimSpace(remoteIp)

	for _, addr := range IPS {
		if addr == remoteIp {
			return
		}
	}

	IPS = append(IPS, remoteIp)
	fmt.Println(IPS)
}

func repartirData() {

	cantidadTotal := len(IPS)
	contador := 0

	for _, direccion := range (IPS) {
		remote := fmt.Sprintf("%s", direccion)
		conn, _ := net.Dial("tcp", remote)

		fmt.Fprintln(conn, k)
		conn.Close()
	}

	for _, fila := range DatasetStrings {
		if contador >= cantidadTotal {
			contador = 0
		}

		remote := fmt.Sprintf("%s", IPS[contador])
		conn, _ := net.Dial("tcp", remote)

		fmt.Fprintln(conn, fila)
		conn.Close()

		contador++
	}
}

func transferencia() {
	for _, direccion := range (IPS) {
		remote := fmt.Sprintf("%s", direccion)
		conn, _ := net.Dial("tcp", remote)

		fmt.Fprintln(conn, "Termino\n")
		conn.Close()
	}
}

func losResultados(hostAddr string) {
	host := fmt.Sprintf("%s:8001", hostAddr)
	ln, _ := net.Listen("tcp", host)
	defer ln.Close()

	for {
		conn, _ := ln.Accept()
		go validar(conn)
	}
}

func validar(conn net.Conn) {
	defer conn.Close()

	r := bufio.NewReader(conn)
	lineaResultado, _ := r.ReadString('\n')
	lineaResultado = strings.TrimSpace(lineaResultado)

	fmt.Println("Recepcionado \n")
	fmt.Println(lineaResultado + "\n")

	nuevasRespuestas.Lock()
	Distancias = append(Distancias, retoText(lineaResultado))

	if len(Distancias) == len(IPS)*k {
		respuestas.Unlock()
	}

	nuevasRespuestas.Unlock()
}

func ImprimirRespuestas() {
	respuestas.Lock()

	ordenar()

	clase := claseRespuesta()
	fmt.Printf("La clase resultante es %d", clase)

	respuestas.Unlock()
}

func claseRespuesta() int {
	fmt.Println("Calculando respuesta \n")

	contador_clases := make(map[int]int)

	for i := 0; i < k; i++ {
		instancia := Distancias[i].Instancia
		log.Printf("Instancia resultante %d: %s", i + 1, toText(Distancias[i]))
		tam := len(instancia)
		clase := instancia[tam - 1]

		if val, ok := contador_clases[clase]; ok {
			contador_clases[clase] = val + 1
		} else {
			contador_clases[clase] = 1
		}
	}

	mejor_clase := -1
	mejor := -1

	for llave, valor := range contador_clases {
		if valor > mejor {
			mejor_clase = llave
			mejor = valor
		}
	}

	return mejor_clase
}

func ordenar() {
	sort.Slice(Distancias, func(primero, segundo int) bool {
		return Distancias[primero].Distancia < Distancias[segundo].Distancia
	})
}

func toText(instancia Knn) string {
	var resultado string

	for _, numero := range instancia.Instancia {
		resultado += strconv.FormatInt(int64(numero), 10) + ","
	}

	resultado += strconv.FormatFloat(instancia.Distancia, 'f', -1, 64)

	return resultado
}

func retoText(resultado string) Knn {
	elementos := strings.Split(resultado, ",")
	var intSlice []int

	for i := 0; i < 6; i++ {
		if elementos[i] == "0" {
			intSlice = append(intSlice, 0)
		} else {
			parsed, err := strconv.Atoi(elementos[i])

			if err != nil {
				panic(err)
			}

			intSlice = append(intSlice, parsed)
		}
	}

	distancia, _ := strconv.ParseFloat(elementos[6], 64)

	return Knn{
		Instancia: intSlice,
		Distancia: distancia,
	}
}