package CS

import (
	"bufio"
	"fmt"
	"net"
	"os"
	"strconv"
	"strings"
	"sync"
	"math"
	"sort"
)

var ipC string
var puerto string
var InstanciaR []int
var ipS string
var puertoEntrara string
var puertoSalida string

var parteData [][]int

var Datos = true
var NuevoIP = &sync.Mutex{}
var knn = &sync.Mutex{}
var Datos2 = &sync.Mutex{}



func Cliente() {
	// Ingresar IP
	ipC = "192.168.1.15"

	fmt.Printf("Tu IP es: %s\n", ipC)

	gin := bufio.NewReader(os.Stdin)
	ipS = ""

	for ipS == "" {
		fmt.Print("Ingrese IP del servidor: ")

		ipS, _ = gin.ReadString('\n')
		ipS = strings.TrimSpace(ipS)

		if ipS == "" {
			fmt.Print("Ingrese direccion correcta\n")
		}
	}

	puertoEntrara = "8000"
	puertoSalida = "8001"

	puerto = ""

	for puerto == "" {
		fmt.Print("Ingrese puerto: ")

		puerto, _ = gin.ReadString('\n')
		puerto = strings.TrimSpace(puerto)

		if puerto == "" {
			fmt.Print("Puerto invalido\n")
		}
	}

	AgregarNodo(ipS, puertoEntrara, ipC, puerto)

	knn.Lock()
	Datos2.Lock()
	go NuevoDato()
	go KNN()
	Resultado()

	fmt.Print("Enter para salir \n")
	gin.ReadString('\n')
}

func AgregarNodo(ipS, puertoRaiz, ipC, puerto string) {
	remote := fmt.Sprintf("%s:%s", ipS, puertoRaiz)
	conn, _ := net.Dial("tcp", remote)
	defer conn.Close()

	local := fmt.Sprintf("%s:%s", ipC, puerto)
	fmt.Fprintln(conn, local)
}

func NuevoDato() {
	host := fmt.Sprintf("%s:%s", ipC, puerto)
	ln, _ := net.Listen("tcp", host)
	defer ln.Close()

	for Datos {
		conn, _ := ln.Accept()
		go Leer(conn)
	}
}

func Leer(conn net.Conn) {
	defer conn.Close()

	r := bufio.NewReader(conn)
	lineaDataset, _ := r.ReadString('\n')
	lineaDataset = strings.TrimSpace(lineaDataset)

	if lineaDataset == "Termino" {
		Datos = false
		knn.Unlock()
		return
	}

	if k == -1 {
		k, _ = strconv.Atoi(lineaDataset)
		fmt.Printf("k: %d\n", k)
		return
	}

	if InstanciaR == nil {

		InstanciaR = converToEnteros(lineaDataset)
		return
	}

	distancia := converToEnteros(lineaDataset)

	NuevoIP.Lock()
	parteData = append(parteData, distancia)
	NuevoIP.Unlock()

	fmt.Printf("Recepcionado: %s\n", lineaDataset)
}

func KNN() {
	knn.Lock()
	for _, linea := range parteData {
		distancia := distEuclidiana(InstanciaR, linea)

		Distancias = append(Distancias, Knn{
			Instancia: linea,
			Distancia: distancia,
		})
	}
	OrdenarDistancias()

	knn.Unlock()
	Datos2.Unlock()
}

func Resultado() {
	Datos2.Lock()

	for i := 0; i < k; i++ {
		linea := toText(Distancias[i])
		Mejor(linea)
	}

	Datos2.Unlock()
}

func Mejor(linea string) {
	remote := fmt.Sprintf("%s:%s", ipS, puertoSalida)
	conn, _ := net.Dial("tcp", remote)
	defer conn.Close()

	fmt.Printf("Calculado: %s\n", linea)
	fmt.Fprintln(conn, linea)
}

func converToEnteros(line string) []int {
	parsedLine := strings.Split(line, ",")
	var intSlice []int

	for _, element := range parsedLine {
		if element == "?" {
			intSlice = append(intSlice, 0)
		} else {

			parsed, err := strconv.Atoi(element)

			if err != nil {
				panic(err)
			}

			intSlice = append(intSlice, parsed)
		}
	}

	return intSlice
}


func distEuclidiana(target, instance []int) float64 {
	result := 0.0

	for i := 0; i < len(target)-1; i++ { 
		result += math.Pow(float64(target[i]-instance[i]), 2)
	}

	result = math.Sqrt(result)

	return result
}


func OrdenarDistancias() {
	sort.Slice(Distancias, func(primero, segundo int) bool {
		return Distancias[primero].Distancia < Distancias[segundo].Distancia
	})
}

