package main

import (
	"fmt"
	"net"
	"bufio"
	"strings"	
	"math"
	"strconv"
	"sort"
)

var dimensions int
var inputs []string

func main(){
	con,_ := net.Dial("tcp", "192.168.1.15:8000")
			r := bufio.NewReader(con)
			msgInst, _ := r.ReadString('\n')
			newInst := Vec{}
			tempStr := ""
			fmt.Println(msgInst)

			for _, ltr := range msgInst {
				if ltr == ',' {
					e, _ := strconv.ParseFloat(tempStr, 64)
					newInst.elements = append(newInst.elements, e )
					tempStr = ""
				} else{
					tempStr += string(ltr)
				}
			}

			newInst.size = len(newInst.elements)
			newInst.class = ""

			msgData, _ := r.ReadString('\n')
			vecs := format(msgData)
			
			kData, _ := r.ReadString('\n')
			
			kInt, _ := strconv.Atoi(strings.TrimSpace(kData))

			xd := kInt
			
			fmt.Fprintf(con, knn(xd, newInst, vecs))
}


func handle(k string, newInst []float64, ds string, n int, nToEnd* int, con net.Conn){
	defer con.Close()
	//Send dataset

	tempStr := ""
	for i := 0; i < len(newInst) ; i++ {
		tempStr += fmt.Sprintf("%g", newInst[i])
		tempStr += ","
	}

	tempStr += "\n"
	
	fmt.Fprintf(con, tempStr) //Send new inst
	 
	fmt.Fprintf(con, ds) //Send part of dataset

	fmt.Fprintf(con, k + "\n") //Send new inst

	r := bufio.NewReader(con)
	msg, _ := r.ReadString('\n') //Read result
	inputs = append(inputs, msg)
	*nToEnd--
	fmt.Println(msg) //Store result
}



//KNN

type Vec struct{
	size int;
	elements []float64;
	class string;
}

func (v* Vec) distToVec(toV Vec) float64 { //Calculate distance to another Vec

	sums := []float64{};
	var sum float64 = 0;
	
	for i := 0; i < v.size; i++ {
		sums = append(sums, v.elements[i] - toV.elements[i]);
	}

	for i := 0; i < len(sums); i++ {
		sum += math.Pow(sums[i], 2);
	}
	
	return math.Sqrt(sum);
}


func format(ds string) []Vec{
	v := []Vec{}
	newVec := Vec{}
	str := ""
	for i, ltr := range ds {
		if ltr == ','{
			if ds[i+1] == ';' {
				newVec.class = str
				newVec.size = len(newVec.class)
				v = append(v, newVec)
				newVec = Vec{}
				str = ""
			} else {
				e, _ := strconv.ParseFloat(str, 64)
				newVec.elements = append(newVec.elements, e)
				str = ""
			}
		}else {
			str += string(ltr);
		}
	}
	return v
}

func knn(k int, predV Vec, v []Vec) string {

	var class string; //Predicted class
	
	dists := []float64{};
	var dist float64;
	m := make(map[float64]Vec) //Dist to Vec map;

	for i := 0; i < len(v); i++ {
		dist = predV.distToVec(v[i]);
		dists = append(dists, dist);
		m[dist] = v[i];
	}

	sort.Float64s(dists);

	closest := make([]Vec, k);
	count := make(map[string]int);

	for i := 0; i < k; i++ {
		closest[i] = m[dists[i]];
		count[closest[i].class]++;
	}

	max := 0;

	for i, val := range count{
		if(max < val){
			max = val;
			class = i;
		}		
	}

	return class;
}