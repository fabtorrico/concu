package main

import (
	"fmt"
	"net"
	"bufio"
	"strings"
	"os"
	"encoding/csv"
	"io"


)

var dimensions int
var inputs []string

func main(){

	var nodes int
	var isServer string
	k := "";

	fmt.Print("Enter para comenzar ")
	fmt.Scanf("%s\n", &isServer)


	fmt.Print("Ingrese la cantidad de nodos: ")
		fmt.Scanf("%d\n", &nodes)

		fmt.Print("Definir el valor de K: ")
		fmt.Scanf("%s\n", &k)

		ips := make([]string, nodes + 1) // Index 0 is server ip
		ipCounter := 0
		fmt.Print("La ip del servidor: ")
		ips[0] = getOutboundIP()
		fmt.Println(ips[0])
		nodesToEnd := nodes

		datasets := loadCsvAndPartition("transfusion.csv", nodes, true)

		newInstance := make([]float64, dimensions)

		for i := 0; i < dimensions; i++ {
			fmt.Print("Ingrese el valor " + string(i+49) + " de la nueva instancia: ")
			fmt.Scanf("%g\n", &newInstance[i])
		}

		host := fmt.Sprintf("%s:8000", ips[0])
		ln, _ := net.Listen("tcp", host)
		defer ln.Close()
		
		go getResult(&nodesToEnd)
		
		for {
			con, _ := ln.Accept()
			ipCounter++
			ips[ipCounter] = con.LocalAddr().String()
			fmt.Println(con.LocalAddr().String() + " se ha conectado.")
			go handle(k, newInstance, datasets[ipCounter-1], nodes, &nodesToEnd, con)
		}

}

func handle(k string, newInst []float64, ds string, n int, nToEnd* int, con net.Conn){
	defer con.Close()
	//Send dataset

	tempStr := ""
	for i := 0; i < len(newInst) ; i++ {
		tempStr += fmt.Sprintf("%g", newInst[i])
		tempStr += ","
	}

	tempStr += "\n"
	
	fmt.Fprintf(con, tempStr) //Send new inst
	 
	fmt.Fprintf(con, ds) //Send part of dataset

	fmt.Fprintf(con, k + "\n") //Send new inst

	r := bufio.NewReader(con)
	msg, _ := r.ReadString('\n') //Read result
	inputs = append(inputs, msg)
	*nToEnd--
	fmt.Println(msg) //Store result
}

func getOutboundIP() string {
    con, _ := net.Dial("udp", "8.8.8.8:80")
    defer con.Close()
	localAddr := con.LocalAddr().String()
    return strings.Split(localAddr, ":")[0]
}

func loadCsvAndPartition(filePath string, n int, hasHeader bool)  []string{

	ds := []string{}
	it := 0
    // Loading file.
    f, _ := os.Open(filePath)
    // Reader.
	r := csv.NewReader(f)
	record, _ := r.Read()
	dimensions = len(record) - 1
    for {
		record, err := r.Read()
		// Stop at EOF.		
        if err == io.EOF {
            break
        }
        if err != nil {
            panic(err)
		}		
		ds = append(ds,"");
        for _, val := range record {
			ds[it] += val;
			ds[it] += ",";
		}
		ds[it] += ";";
		it++
	}

	div := it/n+1
	res := it%n
	doneOnce := false
	j := 0

	dsF := make([]string, n)

	for i := 0; i < n; i++ {
		for _, e := range ds[j:j+div] {
			dsF[i] += e
		}
		res--
		j+=div
		fmt.Println(j)
		if res <= 0 {
			res = 1
			if doneOnce == false {
				doneOnce = true
				div--
			}
		}
		dsF[i] += "\n"
	}

	return dsF;
}

func getResult(nToEnd* int){
	
	for *nToEnd > 0 {
		
	}

	counterMap := make(map[string]int)

	for i:= 0; i < len(inputs); i++ {
		counterMap[inputs[i]]++
	}

	max := 0
	result := ""

	for i, val := range counterMap {
		if val > max {
			max = val
			result = i
		}
	}
	
	fmt.Println("La clase es: " + result + "!!!!!!!!!!")
}