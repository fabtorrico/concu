package CS

import (
	"bufio"
	"fmt"
	"log"
	"net"
	"os"
	"path/filepath"
	"strconv"
	"strings"
	"sync"
)

var nuevosNodos = true
var nuevasRespuestas = &sync.Mutex{}
var respuestas = &sync.Mutex{}

func IniciarServidor() {
	// Leer dataset
	rutaData := "data.csv"
	leerData(rutaData)

	
	gin := bufio.NewReader(os.Stdin)

	for k <= 0 || k%2 == 0 {
		fmt.Print("Defina el valor de K para el proceso: ")

		newK, _ := gin.ReadString('\n')
		newK = strings.TrimSpace(newK)

		k, _ = strconv.Atoi(newK)

		if k <= 0 {
			fmt.Print("K debe tener un valor positivo\n")
		}

		if k%2 == 0 {
			fmt.Print("K debe representar un numero impar\n")
		}

		if k >= len(DatasetStrings) {
			fmt.Printf("K no puede ser mayor a la cantidad de instancias del dataset (%d)\n", len(DatasetStrings))
		}
	}

	// Ingresar IP
	ipS := "192.168.1.15"
	fmt.Printf("Direccion local %s:8000\n", ipS)

	respuestas.Lock()

	go escucharNodos(ipS)
	go losResultados(ipS)


	fmt.Print("Esperando nodos cliente, presione cualquier boton para iniciar ejecucion\n")
	gin.ReadString('\n')
	nuevosNodos = false

	repartirData()
	transferencia()

	ImprimirRespuestas()
}

func leerData(rutaData string) {
	ubicacionAbsoluta, _ := filepath.Abs(rutaData)

	file, err := os.Open(ubicacionAbsoluta)

	if err != nil {
		log.Fatal(err)
	}

	defer file.Close()

	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := scanner.Text()
		DatasetStrings = append(DatasetStrings, line)
	}

	if err := scanner.Err(); err != nil {
		log.Fatal(err)
	}
}

func escucharNodos(hostAddr string) {
	host := fmt.Sprintf("%s:8000", hostAddr)
	ln, _ := net.Listen("tcp", host)
	defer ln.Close()

	for nuevosNodos {
		conn, _ := ln.Accept()
		go registrarNodo(conn)
	}
}

func registrarNodo(conn net.Conn) {
	defer conn.Close()

	if !nuevosNodos {
		return
	}

	r := bufio.NewReader(conn)
	remoteIp, _ := r.ReadString('\n')
	remoteIp = strings.TrimSpace(remoteIp)

	for _, addr := range IPS {
		if addr == remoteIp {
			return
		}
	}

	IPS = append(IPS, remoteIp)
	fmt.Println(IPS)
}

func repartirData() {

	cantidadTotal := len(IPS)
	contador := 0

	for _, direccion := range (IPS) {
		remote := fmt.Sprintf("%s", direccion)
		conn, _ := net.Dial("tcp", remote)

		fmt.Fprintln(conn, k)
		conn.Close()
	}

	for _, fila := range DatasetStrings {
		if contador >= cantidadTotal {
			contador = 0
		}

		remote := fmt.Sprintf("%s", IPS[contador])
		conn, _ := net.Dial("tcp", remote)

		fmt.Fprintln(conn, fila)
		conn.Close()

		contador++
	}
}

func transferencia() {
	for _, direccion := range (IPS) {
		remote := fmt.Sprintf("%s", direccion)
		conn, _ := net.Dial("tcp", remote)

		fmt.Fprintln(conn, "Termino\n")
		conn.Close()
	}
}

func losResultados(hostAddr string) {
	host := fmt.Sprintf("%s:8001", hostAddr)
	ln, _ := net.Listen("tcp", host)
	defer ln.Close()

	for {
		conn, _ := ln.Accept()
		go validar(conn)
	}
}

func validar(conn net.Conn) {
	defer conn.Close()

	r := bufio.NewReader(conn)
	lineaResultado, _ := r.ReadString('\n')
	lineaResultado = strings.TrimSpace(lineaResultado)

	fmt.Println("Recibido resultado\n")
	fmt.Println(lineaResultado + "\n")

	nuevasRespuestas.Lock()
	Distancias = append(Distancias, ConvertirDeTexto(lineaResultado))

	if len(Distancias) == len(IPS)*k {
		respuestas.Unlock()
	}

	nuevasRespuestas.Unlock()
}

func ImprimirRespuestas() {
	respuestas.Lock()

	OrdenarDistancias()

	clase := claseRespuesta()
	fmt.Printf("La clase resultante es %d", clase)

	respuestas.Unlock()
}

func claseRespuesta() int {
	fmt.Println("Determinando clase...\n")

	contador_clases := make(map[int]int)

	for i := 0; i < k; i++ {
		instancia := Distancias[i].Instancia
		log.Printf("Instancia %d: %s", i + 1, ConvertirATexto(Distancias[i]))
		tam := len(instancia)
		clase := instancia[tam - 1]

		if val, ok := contador_clases[clase]; ok {
			contador_clases[clase] = val + 1
		} else {
			contador_clases[clase] = 1
		}
	}

	mejor_clase := -1
	mejor := -1

	for llave, valor := range contador_clases {
		if valor > mejor {
			mejor_clase = llave
			mejor = valor
		}
	}

	return mejor_clase
}