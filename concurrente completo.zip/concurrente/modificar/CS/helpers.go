package CS

import (
	"math"
	"sort"
	"strconv"
	"strings"
)

var k = -1

var InstanciaR []int

var IPS []string
var parteData [][]int
var DatasetStrings []string
var Distancias []Knn

type Knn struct {
	Instancia []int
	Distancia float64
}


func ConvertirAEnteros(line string) []int {
	// Leer linea de datos separados por coma y convertirlos a un slice de enteros
	parsedLine := strings.Split(line, ",")
	var intSlice []int

	for _, element := range parsedLine {
		if element == "?" {
			intSlice = append(intSlice, 0)
		} else {

			parsed, err := strconv.Atoi(element)

			if err != nil {
				panic(err)
			}

			intSlice = append(intSlice, parsed)
		}
	}

	return intSlice
}

func CalcularEuclidiana(target, instance []int) float64 {
	// Calcular distancia euclidiana entre la instancia objetivo y una instancia existente
	result := 0.0

	for i := 0; i < len(target)-1; i++ { // len(target) - 1 para no contar el atributo clase
		result += math.Pow(float64(target[i]-instance[i]), 2)
	}

	result = math.Sqrt(result)

	return result
}


func OrdenarDistancias() {
	sort.Slice(Distancias, func(primero, segundo int) bool {
		return Distancias[primero].Distancia < Distancias[segundo].Distancia
	})
}

func ConvertirATexto(instancia Knn) string {
	var resultado string

	for _, numero := range instancia.Instancia {
		resultado += strconv.FormatInt(int64(numero), 10) + ","
	}

	resultado += strconv.FormatFloat(instancia.Distancia, 'f', -1, 64)

	return resultado
}

func ConvertirDeTexto(resultado string) Knn {
	// Leer linea de datos separados por coma y convertirlos a un slice de enteros
	elementos := strings.Split(resultado, ",")
	var intSlice []int

	for i := 0; i < 6; i++ {
		if elementos[i] == "0" {
			intSlice = append(intSlice, 0)
		} else {
			parsed, err := strconv.Atoi(elementos[i])

			if err != nil {
				panic(err)
			}

			intSlice = append(intSlice, parsed)
		}
	}

	distancia, _ := strconv.ParseFloat(elementos[6], 64)

	return Knn{
		Instancia: intSlice,
		Distancia: distancia,
	}
}
