package main

import (
	"bufio"
	"fmt"
	"tf/CS"
	"os"
	"strings"
)

func main() {
	gin := bufio.NewReader(os.Stdin)
	rol := ""

	for rol == "" {
		fmt.Print("Es el servidor? y/n \n")

		rol, _ = gin.ReadString('\n')
		rol = strings.TrimSpace(rol)

		if rol == "Y" || rol == "y" {
			fmt.Print("Usted es servidor \n")
			CS.IniciarServidor()
		} else if rol == "N" || rol == "n" {
			fmt.Print("Usted es cliente \n")
			CS.Cliente()
		} else {
			fmt.Print("ingrese una opcion correcta\n")
		}
	}
}