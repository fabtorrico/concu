package main

import (
	"bufio"
	"fmt"
	"os"
	"strings"
	"log"
	"net"
	"math"
	"path/filepath"
	"strconv"
	"sync"
	"sort"
)

func main() {
	gin := bufio.NewReader(os.Stdin)
	rol := ""

	for rol == "" {
		fmt.Print("Es el servidor? y/n \n")

		rol, _ = gin.ReadString('\n')
		rol = strings.TrimSpace(rol)

		if rol == "Y" || rol == "y" {
			fmt.Print("Usted es servidor \n")
			Servidor()
		} else if rol == "N" || rol == "n" {
			fmt.Print("Usted es cliente \n")
			Cliente()
		} else {
			fmt.Print("ingrese una opcion correcta\n")
		}
	}
}

//ingresar IP y data
var ipS string = "192.168.1.15"
var ipC string = "192.168.1.15"
var rutaData string = "data.csv"

var puerto string
var InstanciaR []int
var puertoEntrara string
var puertoSalida string

var parteData [][]int

var Datos = true
var NuevoIP = &sync.Mutex{}
var knn = &sync.Mutex{}
var Datos2 = &sync.Mutex{}

var k = -1
var nuevosNodos = true
var nuevasRespuestas = &sync.Mutex{}
var respuestas = &sync.Mutex{}
var IPS []string
var DatasetStrings []string
var Distancias []Knn

type Knn struct {
	Instancia []int
	Distancia float64
}

func Servidor() {

	
	leerData(rutaData)

	
	gin := bufio.NewReader(os.Stdin)

	for k <= 0 || k%2 == 0 {
		fmt.Print("Ingresar valor de K: ")

		newK, _ := gin.ReadString('\n')
		newK = strings.TrimSpace(newK)

		k, _ = strconv.Atoi(newK)

		if k <= 0 {
			fmt.Print("K tiene que ser positivo\n")
		}

		if k%2 == 0 {
			fmt.Print("K tiene que ser impar\n")
		}

		if k >= len(DatasetStrings) {
			fmt.Printf("K tiene que ser neor a las instancias del dataset (%d)\n", len(DatasetStrings))
		}
	}

	fmt.Printf("Tu IP es %s:8000\n", ipS)

	respuestas.Lock()

	go escucharNodos(ipS)
	go losResultados(ipS)


	fmt.Print("Esperando clientes, presionar enter para empezar\n")
	gin.ReadString('\n')
	nuevosNodos = false

	repartirData()
	transferencia()

	ImprimirRespuestas()
}

func leerData(rutaData string) {
	ubicacionAbsoluta, _ := filepath.Abs(rutaData)

	file, err := os.Open(ubicacionAbsoluta)

	if err != nil {
		log.Fatal(err)
	}

	defer file.Close()

	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		line := scanner.Text()
		DatasetStrings = append(DatasetStrings, line)
	}

	if err := scanner.Err(); err != nil {
		log.Fatal(err)
	}
}

func escucharNodos(hostAddr string) {
	host := fmt.Sprintf("%s:8000", hostAddr)
	ln, _ := net.Listen("tcp", host)
	defer ln.Close()

	for nuevosNodos {
		conn, _ := ln.Accept()
		go registrarNodo(conn)
	}
}

func registrarNodo(conn net.Conn) {
	defer conn.Close()

	if !nuevosNodos {
		return
	}

	r := bufio.NewReader(conn)
	remoteIp, _ := r.ReadString('\n')
	remoteIp = strings.TrimSpace(remoteIp)

	for _, addr := range IPS {
		if addr == remoteIp {
			return
		}
	}

	IPS = append(IPS, remoteIp)
	fmt.Println(IPS)
}

func repartirData() {

	cantidadTotal := len(IPS)
	contador := 0

	for _, direccion := range (IPS) {
		remote := fmt.Sprintf("%s", direccion)
		conn, _ := net.Dial("tcp", remote)

		fmt.Fprintln(conn, k)
		conn.Close()
	}

	for _, fila := range DatasetStrings {
		if contador >= cantidadTotal {
			contador = 0
		}

		remote := fmt.Sprintf("%s", IPS[contador])
		conn, _ := net.Dial("tcp", remote)

		fmt.Fprintln(conn, fila)
		conn.Close()

		contador++
	}
}

func transferencia() {
	for _, direccion := range (IPS) {
		remote := fmt.Sprintf("%s", direccion)
		conn, _ := net.Dial("tcp", remote)

		fmt.Fprintln(conn, "Termino\n")
		conn.Close()
	}
}

func losResultados(hostAddr string) {
	host := fmt.Sprintf("%s:8001", hostAddr)
	ln, _ := net.Listen("tcp", host)
	defer ln.Close()

	for {
		conn, _ := ln.Accept()
		go validar(conn)
	}
}

func validar(conn net.Conn) {
	defer conn.Close()

	r := bufio.NewReader(conn)
	lineaResultado, _ := r.ReadString('\n')
	lineaResultado = strings.TrimSpace(lineaResultado)

	fmt.Println("Recepcionado \n")
	fmt.Println(lineaResultado + "\n")

	nuevasRespuestas.Lock()
	Distancias = append(Distancias, retoText(lineaResultado))

	if len(Distancias) == len(IPS)*k {
		respuestas.Unlock()
	}

	nuevasRespuestas.Unlock()
}

func ImprimirRespuestas() {
	respuestas.Lock()

	ordenar()

	clase := claseRespuesta()
	fmt.Printf("La clase resultante es %d", clase)

	respuestas.Unlock()
}

func claseRespuesta() int {
	fmt.Println("Calculando respuesta \n")

	contador_clases := make(map[int]int)

	for i := 0; i < k; i++ {
		instancia := Distancias[i].Instancia
		log.Printf("Instancia resultante %d: %s", i + 1, toText(Distancias[i]))
		tam := len(instancia)
		clase := instancia[tam - 1]

		if val, ok := contador_clases[clase]; ok {
			contador_clases[clase] = val + 1
		} else {
			contador_clases[clase] = 1
		}
	}

	mejor_clase := -1
	mejor := -1

	for llave, valor := range contador_clases {
		if valor > mejor {
			mejor_clase = llave
			mejor = valor
		}
	}

	return mejor_clase
}

func ordenar() {
	sort.Slice(Distancias, func(primero, segundo int) bool {
		return Distancias[primero].Distancia < Distancias[segundo].Distancia
	})
}

func toText(instancia Knn) string {
	var resultado string

	for _, numero := range instancia.Instancia {
		resultado += strconv.FormatInt(int64(numero), 10) + ","
	}

	resultado += strconv.FormatFloat(instancia.Distancia, 'f', -1, 64)

	return resultado
}

func retoText(resultado string) Knn {
	elementos := strings.Split(resultado, ",")
	var intSlice []int

	for i := 0; i < 6; i++ {
		if elementos[i] == "0" {
			intSlice = append(intSlice, 0)
		} else {
			parsed, err := strconv.Atoi(elementos[i])

			if err != nil {
				panic(err)
			}

			intSlice = append(intSlice, parsed)
		}
	}

	distancia, _ := strconv.ParseFloat(elementos[6], 64)

	return Knn{
		Instancia: intSlice,
		Distancia: distancia,
	}
}







func Cliente() {

	fmt.Printf("Tu IP es: %s\n", ipC)

	gin := bufio.NewReader(os.Stdin)
	ipS = ""

	for ipS == "" {
		fmt.Print("Ingrese IP del servidor: ")

		ipS, _ = gin.ReadString('\n')
		ipS = strings.TrimSpace(ipS)

		if ipS == "" {
			fmt.Print("Ingrese direccion correcta\n")
		}
	}

	puertoEntrara = "8000"
	puertoSalida = "8001"

	puerto = ""

	for puerto == "" {
		fmt.Print("Ingrese puerto: ")

		puerto, _ = gin.ReadString('\n')
		puerto = strings.TrimSpace(puerto)

		if puerto == "" {
			fmt.Print("Puerto invalido\n")
		}
	}

	AgregarNodo(ipS, puertoEntrara, ipC, puerto)

	knn.Lock()
	Datos2.Lock()
	go NuevoDato()
	go KNN()
	Resultado()

	fmt.Print("Enter para salir \n")
	gin.ReadString('\n')
}

func AgregarNodo(ipS, puertoRaiz, ipC, puerto string) {
	remote := fmt.Sprintf("%s:%s", ipS, puertoRaiz)
	conn, _ := net.Dial("tcp", remote)
	defer conn.Close()

	local := fmt.Sprintf("%s:%s", ipC, puerto)
	fmt.Fprintln(conn, local)
}

func NuevoDato() {
	host := fmt.Sprintf("%s:%s", ipC, puerto)
	ln, _ := net.Listen("tcp", host)
	defer ln.Close()

	for Datos {
		conn, _ := ln.Accept()
		go Leer(conn)
	}
}

func Leer(conn net.Conn) {
	defer conn.Close()

	r := bufio.NewReader(conn)
	lineaDataset, _ := r.ReadString('\n')
	lineaDataset = strings.TrimSpace(lineaDataset)

	if lineaDataset == "Termino" {
		Datos = false
		knn.Unlock()
		return
	}

	if k == -1 {
		k, _ = strconv.Atoi(lineaDataset)
		fmt.Printf("k: %d\n", k)
		return
	}

	if InstanciaR == nil {

		InstanciaR = converToEnteros(lineaDataset)
		return
	}

	distancia := converToEnteros(lineaDataset)

	NuevoIP.Lock()
	parteData = append(parteData, distancia)
	NuevoIP.Unlock()

	fmt.Printf("Recepcionado: %s\n", lineaDataset)
}

func KNN() {
	knn.Lock()
	for _, linea := range parteData {
		distancia := distEuclidiana(InstanciaR, linea)

		Distancias = append(Distancias, Knn{
			Instancia: linea,
			Distancia: distancia,
		})
	}
	OrdenarDistancias()

	knn.Unlock()
	Datos2.Unlock()
}

func Resultado() {
	Datos2.Lock()

	for i := 0; i < k; i++ {
		linea := toText(Distancias[i])
		Mejor(linea)
	}

	Datos2.Unlock()
}

func Mejor(linea string) {
	remote := fmt.Sprintf("%s:%s", ipS, puertoSalida)
	conn, _ := net.Dial("tcp", remote)
	defer conn.Close()

	fmt.Printf("Calculado: %s\n", linea)
	fmt.Fprintln(conn, linea)
}

func converToEnteros(line string) []int {
	parsedLine := strings.Split(line, ",")
	var intSlice []int

	for _, element := range parsedLine {
		if element == "?" {
			intSlice = append(intSlice, 0)
		} else {

			parsed, err := strconv.Atoi(element)

			if err != nil {
				panic(err)
			}

			intSlice = append(intSlice, parsed)
		}
	}

	return intSlice
}


func distEuclidiana(target, instance []int) float64 {
	result := 0.0

	for i := 0; i < len(target)-1; i++ { 
		result += math.Pow(float64(target[i]-instance[i]), 2)
	}

	result = math.Sqrt(result)

	return result
}


func OrdenarDistancias() {
	sort.Slice(Distancias, func(primero, segundo int) bool {
		return Distancias[primero].Distancia < Distancias[segundo].Distancia
	})
}

