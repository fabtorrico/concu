package main

import (
	"bufio"
	"fmt"
	"net"
)

func main(){
	ln, _ := net.Listen("tcp", "localhost:8000")
	defer ln.Close()
	con, _ := ln.Accept()
	r := bufio.NewReader(con)
	msg, _ := r.ReadString('\n')
	fmt.Print(msg)
}

