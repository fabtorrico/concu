package main

import (
	"bufio"
	"fmt"
	"net"
)

func main(){
	ln, _ := net.Listen("tcp", "10.11.98.215:8000")
	defer ln.Close()
	for{
		con, _ := ln.Accept()
		go handle(con)
	}
}

func handle(con net.Conn){
	defer con.Close()
	r := bufio.NewReader(con)
	for{
		msg, err := r.ReadString('\n')
		if err != nil{
			break
		}
	fmt.Printf("Recibido: %s", msg)
	fmt.Fprint(con,msg)
	}
	
}

