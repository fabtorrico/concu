package main

import (
	"encoding/json"
	"fmt"
)

type Person struct{
	Name string 
	Estatura float32
	MyAddr Address
}

type Address struct{
	Calle string
	Nro int
}

func main(){
	personas := []Person{
		{"Jon", 1.8, Address{"Primavera",2350}},
		{"Rosa", 1.9, Address{"Benavides",112}},
		{"Maria", 1.6, Address{"Angamos",332}},
		{"Renzo", 1.83, Address{"La molina",666}}}

		jsonBytes, _ := json.MarshalIndent(personas, "","\t")
		jsonStr := string(jsonBytes)

		fmt.Println(jsonStr)

		var otras []Person
		json.Unmarshal(jsonBytes, &otras)
		fmt.Println(otras)
	
}