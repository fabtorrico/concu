package main

import (
	"bufio"
	"fmt"
	"net"
	"os"
)

func main(){
	ln, _ := net.Listen("tcp", "10.11.98.215:8000")
	defer ln.Close()
	for{
		con, _ := ln.Accept()
		go handle(con)
	}
}

func handle(con net.Conn){
	defer con.Close()
	r := bufio.NewReader(con)
	for{
		msg, err := r.ReadString('\n')
		if err != nil{
			break
		}
	}
	fmt.Printf("Recibido: %s", msg)
	fmt.Frpint(con,msg)
}


func cliente(){
	con, _ := net.Dial("tcp", "10.11.98.216:8000")
	defer con.Close()
	r := bufio.NewReader(con)
	gin := bufio.NewReader(os.Stdin)
	for{
		fmt.Printf("Ingrese mensaje: ")
		msg, _ := gin.ReadString('\n')
		fmt.Fprint(con,msg)
		resp, _ := r.ReadString('\n')
		fmt.Printf("Respuesta: %s", resp) 
	}
}

func main(){
	
	cliente()
}