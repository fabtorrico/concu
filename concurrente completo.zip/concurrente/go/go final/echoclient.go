package main

import (
	"bufio"
	"fmt"
	"net"
	"os"
)

func main(){
	con, _ := net.Dial("tcp", "10.11.98.216:8000")
	defer con.Close()
	r := bufio.NewReader(con)
	gin := bufio.NewReader(os.Stdin)
	for{
		fmt.Printf("Ingrese mensaje: ")
		msg, _ := gin.ReadString('\n')
		fmt.Fprint(con,msg)
		resp, _ := r.ReadString('\n')
		fmt.Printf("Respuesta: %s", resp) 
	}
}