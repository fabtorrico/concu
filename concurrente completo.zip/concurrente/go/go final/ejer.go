package main

import "fmt"


func producer(id int, ch chan string){
	c := 0
	for{
		c++
		ch <- fmt.Sprintf("producto %d made by %d", c , id)
	}
	
}

func consumer(id int , ch chan string){
	for{
		fmt.Printf("consumer %d using %s \n", id, <-ch)
	}
}

func main(){
	ch := make(chan string)
	for i := 0;i <3;i++ {
		go producer(i,ch)
		go consumer(i,ch)
	}
	consumer(3,ch)
}