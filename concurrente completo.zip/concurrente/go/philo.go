package main 

import (
	"fmt"
	"sync"
)

func Philosophers(name string, leftFork, righFork sync.Mutex)  {
	for { 
		fmt.Println(name, "pensando")
		leftFork.Lock()
		righFork.Lock()
		fmt.Println(name, "comiendo")
		leftFork.Unlock()
		righFork.Unlock()
		
	}
}

func main(){
	n := 5
	fork := make([]sync.Mutex,n)
	names := []string{"Socrates","Platon","Descartes","Aristoteles","Nietzsche"}
	for i := 0; i < n ; i++{
		go Philosophers(names[i], fork[i], fork[(i+1) % n])
	}
	Philosophers(names[n - 1], fork[n -1], fork[0])
}