package main

import (
	"fmt"
	"sync"
)

var cont int = 0

func writer(roomEmpty *sync.Mutex){
	for {
		roomEmpty.Lock()
		fmt.Println("Writer stuff 1")
		fmt.Println("Writer stuff 1")
		fmt.Println("Writer stuff 1")
		roomEmpty.Unlock()
	}
}


func reader(roomEmpty,mutex *sync.Mutex){
	for {
		mutex.Lock()
		if cont ==1 {
			roomEmpty.Lock()
		}
		mutex.Unlock()

		fmt.Println("reading stuff 1")
		fmt.Println("reading stuff 1")
		fmt.Println("reading stuff 1")

		mutex.Lock()
		cont--
		if cont ==0 {
			roomEmpty.Unlock()
		}
		mutex.Unlock()
	}
}

func main(){
	roomEmpty := &sync.Mutex{}
	mutex := &sync.Mutex{}
	go reader(roomEmpty, mutex)
	go reader(roomEmpty, mutex)
	writer(roomEmpty)
}